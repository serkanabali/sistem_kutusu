<?php
function CalisanGetir($db, $AktifKullaniciSirket)
{
    $calisanlar = $db->prepare("SELECT c.id as calisan_id, d.adi AS departman_adi, c.adi AS calisan_adi, c.soyadi AS calisan_soyadi, c.email as calisan_email, s.adi AS sirket_adi FROM departmanlar d JOIN calisanlar c ON d.id = c.departmanID JOIN sirketler s ON d.sirketID = s.id where s.adi=?");

    $calisanlar->execute([$AktifKullaniciSirket]);

    return $calisanlar;
}

if (isset($_POST['MesajGonder'])) {
    $Calisan = $_POST['Mesajcalisan'];
    $Mesaj = $_POST['Mesaj'];

    if (empty($Calisan) || empty($Mesaj)) {
        // Gerekli alanlardan biri veya daha fazlası boş
        echo "Lütfen tüm alanları doldurun.";
    } else {


        $mesajolustur = $db->prepare("INSERT INTO `mesajlar`( `gonderenCalisan`, `iletilenCalisan`, `mesaj`) VALUES (?,?,?)");

        $mesajolustur->execute([$AktifKullaniciID, $Calisan, $Mesaj]);
        if ($mesajolustur) {
            //başarı Mesajı
        } else {
            echo"hata";

        }
    }
}

?>
<form action="" method="post" class="calisanlari-goruntule">
    <div class="calisan-ekle">

        <h1>Mesaj Gönder</h1>

        <div class="ekleme-duzen">
            <div class="aciklama">
                <h4>Gönderilecek Çalışan:</h4>
                <h4>Mesaj:</h4>
            </div>
            <div class="aciklama-giris">
                <select name="Mesajcalisan" id="" class="panel-veri-giris" required>
                    <?php
                    $calisanlar = CalisanGetir($db, $AktifKullaniciSirket);
                    while ($row = $calisanlar->fetch(PDO::FETCH_ASSOC)) {
                        echo '<option value="' . $row['calisan_id'] . '">' . $row['calisan_adi'] . " " . $row['calisan_soyadi'] . '</option>';
                    }
                    ?>
                </select>

                <textarea name="Mesaj" id="" cols="30" rows="10" class="panel-veri-giris"></textarea>

            </div>
        </div>
        <input type="submit" value="GÖNDER" name="MesajGonder" class="button">

    </div>
</form>