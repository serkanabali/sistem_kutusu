

<?php

function CalisanGetir($db, $AktifKullaniciSirket)
{
    $calisanlar = $db->prepare("SELECT c.id as calisan_id, d.adi AS departman_adi, c.adi AS calisan_adi, c.soyadi AS calisan_soyadi, c.email as calisan_email, s.adi AS sirket_adi FROM departmanlar d JOIN calisanlar c ON d.id = c.departmanID JOIN sirketler s ON d.sirketID = s.id where s.adi=?");

    $calisanlar->execute([$AktifKullaniciSirket]);

    return $calisanlar;
}

function DepartmanGetir($db, $AktifKullaniciSirket)
{

    $departmanlar = $db->prepare("Select * from departmanlar where sirketID=(Select id from sirketler where adi=?)");

    $departmanlar->execute([$AktifKullaniciSirket]);

    return $departmanlar;
}
?>

<?php
if (isset($_POST['depEklemeOnay'])) {
    $eklemeIsim = $_POST['depEkleIsim'];


    if (empty($eklemeIsim)) {
        // Gerekli alanlardan biri veya daha fazlası boş
        echo "Lütfen tüm alanları doldurun.";
    } else {

            $departmanlar = $db->prepare("INSERT INTO departmanlar (adi, sirketID)VALUES (?, (SELECT id FROM sirketler WHERE adi = ?))");

            $departmanlar->execute([$eklemeIsim,$AktifKullaniciSirket]);
            if ($departmanlar) {
                //başarı Mesajı
            }
    }
}
?>

<?php
if (isset($_POST['departmanSil'])) {
    if (isset($_POST['checkboxkontrol'])) {
            $SeciliElemanlarSilme = $_POST['checkboxkontrol'];

        foreach ($SeciliElemanlarSilme as $eleman) {
            $SilmeIslemi = $db->query("DELETE FROM departmanlar WHERE ID=$eleman", PDO::FETCH_ASSOC);
        }       
    } else {
        
    } 
}


if (isset($_POST['departmanDuzenle'])) {
    $SeciliDepartmanDuzenleme = $_POST['checkboxkontrol'];
    if (!empty($SeciliDepartmanDuzenleme)) {
        $DepartmanSayisi = count($SeciliDepartmanDuzenleme);
        if ($DepartmanSayisi == 1) {
            $düzenlecekDepartman = $db->prepare("SELECT departmanlar.adi as departmanadi, departmanlar.id as departmanid
            FROM Departmanlar
            JOIN Sirketler ON departmanlar.sirketid = Sirketler.id where Sirketler.id = ?
            
            ");

            $düzenlecekDepartman->execute([$AktifKullaniciSirketID]);
            $row = $düzenlecekDepartman->fetch(PDO::FETCH_ASSOC);

            $DuzenlemeAdGonder = $row['departmanadi'];
         
            $DuzenlemeIDGonder = $row['departmanid'];
        } else {
            echo "Yalnızca bir departman seçiniz";
        }
    } else {
        // hata mesajı
    }
}


if (isset($_POST['depDuzenleOnay'])) {
    $duzenlemeAd = $_POST['DepartmanDuzenleIsim'];
    $duzenlemeID = $_POST['DepartmanDuzenleID'];

    if (empty($duzenlemeAd) || empty($duzenlemeID) ) {
        // Gerekli alanlardan biri veya daha fazlası boş
        echo "Lütfen tüm alanları doldurun.";
    } else {

        $GuncellemeEleman = $db->prepare("UPDATE `departmanlar` SET `adi`=?where id =?");
        $GuncellemeEleman->execute([$duzenlemeAd,$duzenlemeID]);

        if ($GuncellemeEleman) {
            echo "İşlem Başarılı";
        } else {
            echo "İşlem Başarısız";
        }
    }
}
?>


<div class="calisanlar">
    <div class="calisanlari-listele">
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisanlar-ust-kisim">
                <input type="submit" value="SİL" name="departmanSil" class="button">
                <input type="submit" value="DÜZENLE" name="departmanDuzenle" class="button">
                <div class="arama">
                    <input type="text" name="calisanArama" id="calisanArama" placeholder="Ara" class="Arama-Text">
                </div>
            </div>
            <div class="calisanlar-tablo">
                <table>
                    <thead>
                        <tr>
                            <th>Sıra</th>
                            <th><input type="checkbox"></th>
                            <th>Adi</th>
                        </tr>
                    </thead>
                    <tbody id="tbTablo">

                        <?php
                        $departmanlar = DepartmanGetir($db, $AktifKullaniciSirket);
                        $deger = 1;

                        while ($row = $departmanlar->fetch(PDO::FETCH_ASSOC)) {
                            echo "<tr>";
                            echo "<td>$deger</td>";
                            echo "<td><input type='checkbox' name=checkboxkontrol[] value='" . $row['id'] . "'></td>";
                            echo "<td>" . $row['adi'] . "</td>";                      
                            echo "</tr>";
                            $deger++;
                        }
                        ?>


                    </tbody>
                </table>
            </div>
        </form>
    </div>

    <div class="yatay-tutucu">
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisan-ekle">

                <h1>DEPARTMAN DÜZENLE</h1>

                <div class="ekleme-duzen">
                    <div class="aciklama">
                        <h4>Adi:</h4>                     
                    </div>
                    <div class="aciklama-giris">
                    <?php
                        if (!empty($DuzenlemeIDGonder)) {
                            echo '<input type="text" required name="DepartmanDuzenleIsim"  value="' . $DuzenlemeAdGonder . ' "class="panel-veri-giris">  ';
                            
                            echo '<input type="text"  name="DepartmanDuzenleID" value="' . $DuzenlemeIDGonder . '" style="position: absolute;visibility: hidden;" class="panel-veri-giris">';
                        } else {
                            echo '<input type="text" required name="depDuzenleIsim" class="panel-veri-giris">';
                         
                        }
                        ?>
                                      
                    </div>
                </div>
                <input type="submit" value="KAYDET" name="depDuzenleOnay" class="button">

            </div>
        </form>
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisan-ekle">

                <h1>DEPARTMAN EKLE</h1>

                <div class="ekleme-duzen">
                    <div class="aciklama">
                        <h4>Departman Adi:</h4>
                        
                    </div>
                    <div class="aciklama-giris">
                        <input type="text" required name="depEkleIsim" class="panel-veri-giris">                     
                    </div>
                </div>
                <input type="submit" value="KAYDET" name="depEklemeOnay" class="button">

            </div>
        </form>
    </div>

</div>

