<?php

function CalisanGetir($db, $AktifKullaniciSirket)
{
    $calisanlar = $db->prepare("SELECT c.id as calisan_id, d.adi AS departman_adi, c.adi AS calisan_adi, c.soyadi AS calisan_soyadi, c.email as calisan_email, s.adi AS sirket_adi FROM departmanlar d JOIN calisanlar c ON d.id = c.departmanID JOIN sirketler s ON d.sirketID = s.id where s.adi=?");

    $calisanlar->execute([$AktifKullaniciSirket]);

    return $calisanlar;
}

function DepartmanGetir($db, $AktifKullaniciSirket)
{

    $departmanlar = $db->prepare("Select adi from departmanlar where sirketID=(Select id from sirketler where adi=?)");

    $departmanlar->execute([$AktifKullaniciSirket]);

    return $departmanlar;
}
?>

<?php
if (isset($_POST['calisanEklemeOnay'])) {
    $eklemeIsim = $_POST['CalEkleIsim'];
    $eklemeSoyisim = $_POST['CalEkleSoyisim'];
    $eklemeEmail = $_POST['CalEkleEmail'];
    $eklemeDepartman = $_POST['CalEklemeDepartman'];
    $eklemeParola = $_POST['CalEkleParola'];
    $eklemeParolaTekrar = $_POST['CalEkleParolaTekrar'];

    if (empty($eklemeIsim) || empty($eklemeSoyisim) || empty($eklemeEmail) || empty($eklemeDepartman) || empty($eklemeParola) || empty($eklemeParolaTekrar)) {
        // Gerekli alanlardan biri veya daha fazlası boş
        echo "Lütfen tüm alanları doldurun.";
    } else {

        if ($eklemeParola === $eklemeParolaTekrar) {
            $SifrelenmisSifre = password_hash($eklemeParola, PASSWORD_DEFAULT);
            $departmanlar = $db->prepare("INSERT INTO calisanlar (adi, soyadi, email, parola, departmanID) 
            VALUES (?, ?, ?, ?, (SELECT id FROM departmanlar WHERE adi = ? AND sirketID = (Select id from sirketler where adi=?)))");

            $departmanlar->execute([$eklemeIsim, $eklemeSoyisim, $eklemeEmail, $SifrelenmisSifre, $eklemeDepartman, $AktifKullaniciSirket]);
            if ($departmanlar) {
                //başarı Mesajı
            }
        } else {
            // Parolalar eşleşmiyor, hata mesajı gösterilebilir veya işlem durdurulabilir
            echo $eklemeDepartman;
        }
    }
}

if (isset($_POST['calisanSil'])) {
    if (isset($_POST['checkboxkontrol'])) {
        $SeciliElemanlarSilme = $_POST['checkboxkontrol'];

        foreach ($SeciliElemanlarSilme as $eleman) {
            $SilmeIslemi = $db->query("DELETE FROM calisanlar WHERE ID=$eleman", PDO::FETCH_ASSOC);
        }
    } else {
    }
}

if (isset($_POST['calisanDuzenle'])) {
    $SeciliElemanlarDuzenleme = $_POST['checkboxkontrol'];
    if (!empty($SeciliElemanlarDuzenleme)) {
        $elemanSayisi = count($SeciliElemanlarDuzenleme);
        if ($elemanSayisi == 1) {
            $düzenlecekEleman = $db->prepare("SELECT d.adi as calisandepartman, c.id as calisanID ,c.adi as calisanad, c.soyadi as calisansoyad, c.email as calisanmail
            FROM calisanlar c
            JOIN departmanlar d ON c.departmanID = d.id
            WHERE c.id = ?
            ");

            $düzenlecekEleman->execute([$SeciliElemanlarDuzenleme[0]]);
            $row = $düzenlecekEleman->fetch(PDO::FETCH_ASSOC);

            $DuzenlemeIsimGonder = $row['calisanad'];
            $DuzenlemeSoyadGonder = $row['calisansoyad'];
            $DuzenlemeMailGonder = $row['calisanmail'];
            $DuzenlemeDepartmanGonder = $row['calisandepartman'];
            $DuzenlemeIDGonder = $row['calisanID'];
        } else {
            echo "Yalnızca bir eleman seçiniz";
        }
    } else {
        // hata mesajı
    }
}
if (isset($_POST['calisanDuzenleOnay'])) {
    $duzenlemeIsim = $_POST['CalDuzenleIsim'];
    $duzenlemeSoyisim = $_POST['CalDuzenleSoyisim'];
    $duzenlemeEmail = $_POST['CalDuzenleEmail'];
    $duzenlemeDepartman = $_POST['CalDuzenleDepartman'];
    $duzenlemeParola = $_POST['CalDuzenleParola'];
    $duzenlemeParolaTekrar = $_POST['CalDuzenleParolaTekrar'];
    $düzenlecekElemanID = $_POST['CalDuzenleID'];

    if (empty($duzenlemeIsim) || empty($duzenlemeSoyisim) || empty($duzenlemeEmail) || empty($duzenlemeDepartman)) {
        // Gerekli alanlardan biri veya daha fazlası boş
        echo "Lütfen tüm alanları doldurun.";
    } else {
        if (empty($duzenlemeParola) && empty($duzenlemeParolaTekrar)) {
            $GuncellemeEleman = $db->prepare("UPDATE `calisanlar` SET `adi`=?, `soyadi`=?, `email`=?, `departmanID`=(SELECT id FROM departmanlar WHERE adi=? AND SirketID=(SELECT id FROM sirketler WHERE adi=?)) WHERE id=?");
            $GuncellemeEleman->execute([$duzenlemeIsim, $duzenlemeSoyisim, $duzenlemeEmail, $duzenlemeDepartman, $AktifKullaniciSirket, $düzenlecekElemanID]);

            if ($GuncellemeEleman) {
                echo "İşlem Başarılı";
            } else {
                echo "İşlem Başarısız";
            }
        } else {
            if ($duzenlemeParola == $duzenlemeParolaTekrar) {
                $duzenlemeSifrelenmisSifre = password_hash($duzenlemeParola, PASSWORD_DEFAULT);
                $GuncellemeEleman = $db->prepare("UPDATE `calisanlar` SET `adi`=?, `soyadi`=?, `email`=?, `parola`=?, `departmanID`=(SELECT id FROM departmanlar WHERE adi=? AND SirketID=(SELECT id FROM sirketler WHERE adi=?)) WHERE id=?");
                $GuncellemeEleman->execute([$duzenlemeIsim, $duzenlemeSoyisim, $duzenlemeEmail, $duzenlemeSifrelenmisSifre, $duzenlemeDepartman, $AktifKullaniciSirket, $düzenlecekElemanID]);

                if ($GuncellemeEleman) {
                    echo "İşlem Başarılı";
                } else {
                    echo "İşlem Başarısız";
                }
            }
        }
    }
}



?>
<div class="calisanlar">
    <div class="calisanlari-listele">
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisanlar-ust-kisim">
                <input type="submit" value="SİL" name="calisanSil" class="button">
                <input type="submit" value="DÜZENLE" name="calisanDuzenle" class="button">
                <div class="arama">
                    <input type="text" name="calisanArama" id="calisanArama" placeholder="Ara" class="Arama-Text">

                </div>
            </div>
            <div class="calisanlar-tablo">
                <table>
                    <thead>
                        <tr>
                            <th>Sıra</th>
                            <th><input type="checkbox"></th>
                            <th>Ad</th>
                            <th>Soyad</th>
                            <th>Mail Adresi</th>
                            <th>Departman</th>
                        </tr>
                    </thead>
                    <tbody id="tbTablo">

                        <?php
                        $calisanlar = CalisanGetir($db, $AktifKullaniciSirket);
                        $deger = 1;

                        while ($row = $calisanlar->fetch(PDO::FETCH_ASSOC)) {
                            echo "<tr>";
                            echo "<td>$deger</td>";
                            echo "<td><input type='checkbox' name=checkboxkontrol[] value='" . $row['calisan_id'] . "'></td>";
                            echo "<td>" . $row['calisan_adi'] . "</td>";
                            echo "<td>" . $row['calisan_soyadi'] . "</td>";
                            echo "<td>" . $row['calisan_email'] . "</td>";
                            echo "<td>" . $row['departman_adi'] . "</td>";
                            echo "</tr>";
                            $deger++;
                        }

                        ?>


                    </tbody>
                </table>
            </div>
        </form>
    </div>

    <div class="yatay-tutucu">
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisan-ekle">

                <h1>ÇALIŞAN DÜZENLE</h1>

                <div class="ekleme-duzen">
                    <div class="aciklama">
                        <h4>İsim:</h4>
                        <h4>Soyisim:</h4>
                        <h4>E-Mail:</h4>
                        <h4>Departman:</h4>
                        <h4>Parola:</h4>
                        <h4>Parola Tekrar:</h4>
                    </div>
                    <div class="aciklama-giris">
                        <?php
                        if (!empty($DuzenlemeIDGonder)) {
                            echo '<input type="text" required name="CalDuzenleIsim" value="' . $DuzenlemeIsimGonder . '" class="panel-veri-giris">';
                            echo '<input type="text" required name="CalDuzenleSoyisim" value="' . $DuzenlemeSoyadGonder . '" class="panel-veri-giris">';
                            echo '<input type="email" required name="CalDuzenleEmail" value="' . $DuzenlemeMailGonder . '" class="panel-veri-giris">';
                            echo '<input type="text"  name="CalDuzenleID" value="' . $DuzenlemeIDGonder . '" style="position: absolute;visibility: hidden;" class="panel-veri-giris">';
                            echo '<select name="CalDuzenleDepartman" id="" value="' . $DuzenlemeDepartmanGonder . '" class="panel-veri-giris" required>';
                            $departmanlar = DepartmanGetir($db, $AktifKullaniciSirket);
                            while ($row = $departmanlar->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['adi'] . '">' . $row['adi'] . '</option>';
                            }
                            echo '</select>';
                        } else {
                            echo '<input type="text" required name="CalDuzenleIsim" class="panel-veri-giris">';
                            echo '<input type="text" required name="CalDuzenleSoyisim" class="panel-veri-giris">';
                            echo '<input type="email" required name="CalDuzenleEmail" class="panel-veri-giris">';
                            echo '<select name="CalDuzenleDepartman" id="" class="panel-veri-giris" required>';
                            $departmanlar = DepartmanGetir($db, $AktifKullaniciSirket);
                            while ($row = $departmanlar->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['adi'] . '">' . $row['adi'] . '</option>';
                            }
                            echo '</select>';
                        }
                        ?>


                        </select>
                        <input type="password" name="CalDuzenleParola" class="panel-veri-giris">
                        <input type="password" name="CalDuzenleParolaTekrar" class="panel-veri-giris">
                    </div>
                </div>
                <input type="submit" value="KAYDET" name="calisanDuzenleOnay" class="button">

            </div>
        </form>
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisan-ekle">

                <h1>ÇALIŞAN EKLE</h1>

                <div class="ekleme-duzen">
                    <div class="aciklama">
                        <h4>İsim:</h4>
                        <h4>Soyisim:</h4>
                        <h4>E-Mail:</h4>
                        <h4>Departman:</h4>
                        <h4>Parola:</h4>
                        <h4>Parola Tekrar:</h4>
                    </div>
                    <div class="aciklama-giris">
                        <input type="text" required name="CalEkleIsim" class="panel-veri-giris">
                        <input type="text" required name="CalEkleSoyisim" class="panel-veri-giris">
                        <input type="email" required name="CalEkleEmail" class="panel-veri-giris">
                        <select name="CalEklemeDepartman" id="" class="panel-veri-giris" required>
                            <?php
                            $departmanlar = DepartmanGetir($db, $AktifKullaniciSirket);
                            while ($row = $departmanlar->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['adi'] . '">' . $row['adi'] . '</option>';
                            }
                            ?>
                        </select>
                        <input type="password" required name="CalEkleParola" class="panel-veri-giris">
                        <input type="password" required name="CalEkleParolaTekrar" class="panel-veri-giris">
                    </div>
                </div>
                <input type="submit" value="KAYDET" name="calisanEklemeOnay" class="button">

            </div>
        </form>
    </div>

</div>