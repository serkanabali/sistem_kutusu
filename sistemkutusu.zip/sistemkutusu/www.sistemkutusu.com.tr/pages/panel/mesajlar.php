<?php
function MesajlarCalisanGetir($db, $AktifKullaniciID)
{
    $kisiler = $db->prepare("SELECT DISTINCT m.gonderenCalisan AS gonderenid, CONCAT(c.adi, ' ', c.soyadi) AS gonderenAdSoyad
    FROM mesajlar m
    JOIN calisanlar c ON m.gonderenCalisan = c.id
    WHERE m.iletilenCalisan = ?
    
     
    ");

    $kisiler->execute([$AktifKullaniciID]);

    return $kisiler;
}
function MesajGetir($db, $GonderenCalisan)
{

    $mesajlar = $db->prepare("select mesaj from mesajlar where gonderenCalisan=?");

    $mesajlar->execute([$GonderenCalisan]);

    return $mesajlar;
}
?>
<?php
if (isset($_POST['mesajCalisan'])) {
    $calisanAdi = $_POST['mesajCalisan'];
    $mesajlar = MesajGetir($db, $calisanAdi);
}

?>
<div class="mesajlasma-sistemi">

    <div class="mesajlasma-calisanlar">
        <form action="" method="post" class="calisanlari-goruntule">
        <div class="order">
            <?php
            $kisiler = MesajlarCalisanGetir($db, $AktifKullaniciID);
            while ($row = $kisiler->fetch(PDO::FETCH_ASSOC)) {
                echo '<div class="mesajlasma-calisan button">
                <input type="submit"  value="' . $row['gonderenid'] . ' " name="mesajCalisan" class="mesajButton"  >
                '.$row['gonderenAdSoyad'].'
                </div>';
            }
            ?>
           
            </div>
        </form>
    </div>

    <div class="mesajlar">
        <?php
        if (!empty($mesajlar)) {

            while ($row = $mesajlar->fetch(PDO::FETCH_ASSOC)) {
                echo '<div class="mesaj">' . $row['mesaj'] . '</div>';
            }
        } else {
            // $mesajlar değişkeni boş ise burası çalışır
            echo '<div class="mesaj">Mesajları Görmek için Çalışan Seçin</div>';
        }

        ?>

    </div>
</div>