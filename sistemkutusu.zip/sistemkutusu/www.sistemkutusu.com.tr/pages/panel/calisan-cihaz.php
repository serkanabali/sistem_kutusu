<?php

function CalisanGetir($db, $AktifKullaniciSirket)
{
    $calisanlar = $db->prepare("SELECT CONCAT(c.adi, ' ', c.soyadi) AS CalisanlarAdSoyad, c.id AS CalisanlarID
    FROM departmanlar d
    JOIN calisanlar c ON d.id = c.departmanID
    JOIN sirketler s ON d.sirketID = s.id
    WHERE s.adi = ?;
    
    ");

    $calisanlar->execute([$AktifKullaniciSirket]);

    return $calisanlar;
}

function CihazGetir($db, $AktifKullaniciSirket)
{

    $cihazlar = $db->prepare("SELECT c.id AS CihazlarID, c.adi AS CihazlarAdi
    FROM sirketler s
    JOIN cihazlar c ON s.id = c.sirketId
    WHERE s.adi = ?");

    $cihazlar->execute([$AktifKullaniciSirket]);

    return $cihazlar;
}
function CalisanCihazGetir($db, $AktifKullaniciSirket)
{
    $calisanCihaz = $db->prepare("SELECT cci.calisanID as CalisanCihazIliskileriCalisanID , cci.id as CalisanCihazIliskileriID ,cci.cihazID as CalisanCihazIliskileriCihazID , calisanlar.adi as CalisanAdi, calisanlar.soyadi as CalisanSoyadi, cihazlar.adi as CihazAdi, sirketler.adi as SirketAdi FROM calisan_cihaz_iliskileri AS cci INNER JOIN calisanlar ON cci.calisanID = calisanlar.id INNER JOIN cihazlar ON cci.cihazID = cihazlar.id INNER JOIN sirketler ON cihazlar.sirketID = sirketler.id WHERE sirketler.adi=?;");

    $calisanCihaz->execute([$AktifKullaniciSirket]);

    return $calisanCihaz;
}
?>

<?php
if (isset($_POST['CalisanCihazEkleme'])) {
    $eklemeCalisan = $_POST['CalCihEklemeCalisan'];
    $eklemeCihaz = $_POST['CalCihEklemeCihaz'];


    if (empty($eklemeCalisan) || empty($eklemeCihaz)) {
        // Gerekli alanlardan biri veya daha fazlası boş
        echo "Lütfen tüm alanları doldurun.";
    } else {
        $EklemeIslemi = $db->query("INSERT INTO `calisan_cihaz_iliskileri`(`calisanID`, `cihazID`) VALUES ('$eklemeCalisan','$eklemeCihaz')", PDO::FETCH_ASSOC);
    }
}


if (isset($_POST['calisanSil'])) {
    if (isset($_POST['checkboxkontrol'])) {
        $SeciliElemanlarSilme = $_POST['checkboxkontrol'];

        foreach ($SeciliElemanlarSilme as $eleman) {
            $SilmeIslemi = $db->query("DELETE FROM calisan_cihaz_iliskileri WHERE ID=$eleman", PDO::FETCH_ASSOC);
        }
    } else {
    }
}

if (isset($_POST['calisanDuzenle'])) {
    $SeciliElemanlarDuzenleme = $_POST['checkboxkontrol'];
    if (!empty($SeciliElemanlarDuzenleme)) {
        $elemanSayisi = count($SeciliElemanlarDuzenleme);
        if ($elemanSayisi == 1) {
            $düzenlecekEleman = $db->prepare("Select * from calisan_cihaz_iliskileri where ID=?
            ");

            $düzenlecekEleman->execute([$SeciliElemanlarDuzenleme[0]]);
            $row = $düzenlecekEleman->fetch(PDO::FETCH_ASSOC);

            $DuzenlemeCalisanID = $row['calisanID'];
            $DuzenlemeCihazID = $row['cihazID'];
            $DuzenlemeID = $row['id'];
        } else {
            echo "Yalnızca bir eleman seçiniz";
        }
    } else {
        // hata mesajı
    }
}
if (isset($_POST['calisanCihazDuzenleOnay'])) {
    $duzenlemeCalisanID = $_POST['CalCihDuzenlemeCalisan'];
    $duzenlemeCihazID = $_POST['CalCihDuzenlemeCihaz'];
    $duzenlemeID = $_POST['CalCihDuzenlemeID'];

    if (empty($duzenlemeCihazID) || empty($duzenlemeCalisanID) || empty($duzenlemeID)) {
        // Gerekli alanlardan biri veya daha fazlası boş
        echo "Lütfen tüm alanları doldurun.";
    } else {
        $GuncellemeSorgusu = $db->prepare("UPDATE `calisan_cihaz_iliskileri` SET `calisanID`=?, `cihazID`=? WHERE id=?");
        $GuncellemeSorgusu->execute([$duzenlemeCalisanID, $duzenlemeCihazID, $duzenlemeID]);
    }
}



?>
<div class="calisanlar">
    <div class="calisanlari-listele">
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisanlar-ust-kisim">
                <input type="submit" value="SİL" name="calisanSil" class="button">
                <input type="submit" value="DÜZENLE" name="calisanDuzenle" class="button">
                <div class="arama">
                    <input type="text" name="calisanArama" id="calisanArama" placeholder="Ara" class="Arama-Text">

                </div>
            </div>
            <div class="calisanlar-tablo">
                <table>
                    <thead>
                        <tr>
                            <th>Sıra</th>
                            <th><input type="checkbox"></th>
                            <th>Ad</th>
                            <th>Soyad</th>
                            <th>Cihaz</th>
                        </tr>
                    </thead>
                    <tbody id="tbTablo">

                        <?php
                        $calisanCihaz = CalisanCihazGetir($db, $AktifKullaniciSirket);
                        $deger = 1;

                        while ($row = $calisanCihaz->fetch(PDO::FETCH_ASSOC)) {
                            echo "<tr>";
                            echo "<td>$deger</td>";
                            echo "<td><input type='checkbox' name=checkboxkontrol[] value='" . $row['CalisanCihazIliskileriID'] . "'></td>";
                            echo "<td>" . $row['CalisanAdi'] . "</td>";
                            echo "<td>" . $row['CalisanSoyadi'] . "</td>";
                            echo "<td>" . $row['CihazAdi'] . "</td>";
                            echo "</tr>";
                            $deger++;
                        }

                        ?>


                    </tbody>
                </table>
            </div>
        </form>
    </div>

    <div class="yatay-tutucu">
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisan-ekle">

                <h1>ÇALIŞAN DÜZENLE</h1>

                <div class="ekleme-duzen">
                    <div class="aciklama">
                        <h4>Çalışan:</h4>
                        <h4>Cihaz</h4>
                    </div>
                    <div class="aciklama-giris">

                        <?php
                        if (!empty($DuzenlemeID)) {
                        
                            echo '<select name="CalCihDuzenlemeCalisan" value="' . $DuzenlemeCalisanID . '" id="" class="panel-veri-giris" required>';
                            $calisanlar = CalisanGetir($db, $AktifKullaniciSirket);
                            while ($row = $calisanlar->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['CalisanlarID'] . '">' . $row['CalisanlarAdSoyad'] . '</option>';
                            }
                            echo '</select>';
                            echo '<select name="CalCihDuzenlemeCihaz" value="' . $DuzenlemeCihazID . '" id="" class="panel-veri-giris" required>';
                            $cihazlar = CihazGetir($db, $AktifKullaniciSirket);
                            while ($row = $cihazlar->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['CihazlarID'] . '">' . $row['CihazlarAdi'] . '</option>';
                            }
                            echo '</select>';
                            echo '<input type="hidden" name="CalCihDuzenlemeID" value="' . $DuzenlemeID . '" class="panel-veri-giris">';
                        } else {
                            echo '<select name="CalCihEklemeCalisan" id="" class="panel-veri-giris" required>';
                            $calisanlar = CalisanGetir($db, $AktifKullaniciSirket);
                            while ($row = $calisanlar->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['CalisanlarID'] . '">' . $row['CalisanlarAdSoyad'] . '</option>';
                            }
                            echo '</select>';
                            echo '<select name="CalCihEklemeCihaz" id="" class="panel-veri-giris" required>';
                            $cihazlar = CihazGetir($db, $AktifKullaniciSirket);
                            while ($row = $cihazlar->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['CihazlarID'] . '">' . $row['CihazlarAdi'] . '</option>';
                            }
                            echo '</select>';
                        }
                        ?>

                       




                    </div>
                </div>
                <input type="submit" value="KAYDET" name="calisanCihazDuzenleOnay" class="button">

            </div>
        </form>
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisan-ekle">

                <h1>ÇALIŞAN-CİHAZ İLİŞKİSİ EKLE</h1>

                <div class="ekleme-duzen">
                    <div class="aciklama">
                        <h4>Çalışan:</h4>
                        <h4>Cihaz</h4>
                    </div>
                    <div class="aciklama-giris">
                        <select name="CalCihEklemeCalisan" id="" class="panel-veri-giris" required>
                            <?php
                            $calisanlar = CalisanGetir($db, $AktifKullaniciSirket);
                            while ($row = $calisanlar->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['CalisanlarID'] . '">' . $row['CalisanlarAdSoyad'] . '</option>';
                            }
                            ?>
                        </select>
                        <select name="CalCihEklemeCihaz" id="" class="panel-veri-giris" required>
                            <?php
                            $cihazlar = CihazGetir($db, $AktifKullaniciSirket);
                            while ($row = $cihazlar->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['CihazlarID'] . '">' . $row['CihazlarAdi'] . '</option>';
                            }
                            ?>
                        </select>

                    </div>
                </div>
                <input type="submit" value="KAYDET" name="CalisanCihazEkleme" class="button">

            </div>
        </form>
    </div>

</div>