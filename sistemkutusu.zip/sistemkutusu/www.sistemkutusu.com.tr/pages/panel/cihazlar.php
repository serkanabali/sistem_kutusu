<?php


function DepartmanGetir($db, $AktifKullaniciSirket)
{

    $departmanlar = $db->prepare("Select adi from departmanlar where sirketID=(Select id from sirketler where adi=?)");

    $departmanlar->execute([$AktifKullaniciSirket]);

    return $departmanlar;
}



function CihazGetir($db, $AktifKullaniciSirket)
{

    $cihazlar = $db->prepare("SELECT c.id AS cihaz_id, s.adi AS sirket_adi, c.adi AS cihaz_adi, c.tur AS cihaz_tur
    FROM sirketler s
    JOIN cihazlar c ON s.id = c.sirketId
    WHERE s.adi = ?");

    $cihazlar->execute([$AktifKullaniciSirket]);

    return $cihazlar;
}

?>



<?php
if (isset($_POST['calisanEklemeOnay'])) {
    $eklemeAdi = $_POST['CalEkleAdi'];
    $eklemeTuru = $_POST['CalEkleTuru'];
    $eklemeSirket = $_POST['CalEklemeSirket'];

    if (empty($eklemeAdi) || empty($eklemeTuru) || empty($eklemeSirket)) {
        // Gerekli alanlardan biri veya daha fazlası boş
        echo "Lütfen tüm alanları doldurun.";
    } else {

        $cihazlar = $db->prepare("INSERT INTO cihazlar (adi,tur,sirketID) 
            VALUES (?, ?, (Select id from sirketler where adi=?))");

        $cihazlar->execute([$eklemeAdi, $eklemeTuru, $AktifKullaniciSirket]);
        if ($cihazlar) {
            //başarı Mesajı

        }
    }
}
?>

<?php
if (isset($_POST['calisanSil'])) {
    if (isset($_POST['checkboxkontrol'])) {
        $SeciliCihazSilme = $_POST['checkboxkontrol'];

        foreach ($SeciliCihazSilme as $Cihaz) {
            $SilmeIslemi = $db->query("DELETE FROM cihazlar WHERE ID=$Cihaz", PDO::FETCH_ASSOC);
        }
    } else {
    }
}


if (isset($_POST['cihazDuzenleOnay'])) {
    $SeciliCihazDuzenleme = $_POST['checkboxkontrol'];
    if (!empty($SeciliCihazDuzenleme)) {
        $CihazSayisi = count($SeciliCihazDuzenleme);
        if ($CihazSayisi == 1) {
            $düzenlecekCihaz = $db->prepare("SELECT cihazlar.adi as cihazadi, cihazlar.id as cihazid, cihazlar.tur as cihaztur
            FROM Cihazlar
            JOIN Sirketler ON Cihazlar.sirketid = Sirketler.id where Sirketler.id = ?
            
            ");

            $düzenlecekCihaz->execute([$AktifKullaniciSirketID]);
            $row = $düzenlecekCihaz->fetch(PDO::FETCH_ASSOC);

            $DuzenlemeAdGonder = $row['cihazadi'];
            $DuzenlemeTurGonder = $row['cihaztur'];
            $DuzenlemeIDGonder = $row['cihazid'];
        } else {
            echo "Yalnızca bir Cihaz seçiniz";
        }
    } else {
        // hata mesajı
    }
}

if (isset($_POST['cihazDuzenleGuncelle'])) {
    $duzenlemeAd = $_POST['CihazDuzenleAdi'];
    $duzenlemeTur = $_POST['CihazDuzenleTur'];
    $duzenlemeID = $_POST['CihazDuzenleID'];

    if (empty($duzenlemeAd) || empty($duzenlemeTur) || empty($duzenlemeID)) {
        // Gerekli alanlardan biri veya daha fazlası boş
        echo "Lütfen tüm alanları doldurun.";
    } else {

        $GuncellemeEleman = $db->prepare("UPDATE `cihazlar` SET `adi`=?, `tur`=? where id =?");
        $GuncellemeEleman->execute([$duzenlemeAd, $duzenlemeTur, $duzenlemeID]);

        if ($GuncellemeEleman) {
            echo "İşlem Başarılı";
        } else {
            echo "İşlem Başarısız";
        }
    }
}


?>


<div class="calisanlar">
    <div class="calisanlari-listele">
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisanlar-ust-kisim">
                <input type="submit" value="SİL" name="calisanSil" class="button">
                <input type="submit" value="DÜZENLE" name="cihazDuzenleOnay" class="button">
                <div class="arama">
                    <input type="text" name="calisanArama" id="calisanArama" placeholder="Ara" class="Arama-Text">
                </div>
            </div>
            <div class="calisanlar-tablo">
                <table>
                    <thead>
                        <tr>
                            <th>Sıra</th>
                            <th><input type="checkbox"></th>
                            <th>Ad</th>
                            <th>Tür</th>
                            <th>Şirket</th>
                        </tr>
                    </thead>
                    <tbody id="tbTablo">

                        <?php
                        $cihazlar = CihazGetir($db, $AktifKullaniciSirket);
                        $deger = 1;

                        while ($row = $cihazlar->fetch(PDO::FETCH_ASSOC)) {
                            echo "<tr>";
                            echo "<td>$deger</td>";
                            echo "<td><input type='checkbox' name=checkboxkontrol[] value='" . $row['cihaz_id'] . "'></td>";
                            echo "<td>" . $row['cihaz_adi'] . "</td>";
                            echo "<td>" . $row['cihaz_tur'] . "</td>";
                            echo "<td>" . $row['sirket_adi'] . "</td>";
                            echo "</tr>";
                            $deger++;
                        }
                        ?>


                    </tbody>
                </table>
            </div>
        </form>
    </div>

    <div class="yatay-tutucu">
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisan-ekle">

                <h1>CİHAZ DÜZENLE</h1>

                <div class="ekleme-duzen">
                    <div class="aciklama">
                        <h4>Ad:</h4>
                        <h4>Tür:</h4>

                    </div>
                    <div class="aciklama-giris">
                        <?php
                        if (!empty($DuzenlemeIDGonder)) {
                            echo '<input type="text" required name="CihazDuzenleAdi" value="' . $DuzenlemeAdGonder . '" class="panel-veri-giris">';
                            echo '<input type="text" required name="CihazDuzenleTur" value="' . $DuzenlemeTurGonder . '" class="panel-veri-giris">';
                            echo '<input type="text"  name="CihazDuzenleID" value="' . $DuzenlemeIDGonder . '" style="position: absolute;visibility: hidden;" class="panel-veri-giris">';
                        } else {
                            echo '<input type="text" required name="CihazDuzenleAdi" class="panel-veri-giris">';
                            echo '<input type="text" required name="CihazDuzenleTuru" class="panel-veri-giris">';
                        }
                        ?>


                    </div>
                </div>
                <input type="submit" value="KAYDET" name="cihazDuzenleGuncelle" class="button">

            </div>
        </form>
        <form action="" method="post" class="calisanlari-goruntule">
            <div class="calisan-ekle">

                <h1>CİHAZ EKLE</h1>

                <div class="ekleme-duzen">
                    <div class="aciklama">
                        <h4>Ad:</h4>
                        <h4>Tür:</h4>
                        <h4>Şirket:</h4>
                    </div>
                    <div class="aciklama-giris">
                        <input type="text" required name="CalEkleAdi" class="panel-veri-giris">
                        <input type="text" required name="CalEkleTuru" class="panel-veri-giris">
                        <select name="CalEklemeSirket" id="" class="panel-veri-giris" required>
                            <?php
                            echo '<option value="' . $AktifKullaniciSirket . '">' . $AktifKullaniciSirket . '</option>';
                            ?>
                        </select>
                    </div>
                </div>
                <input type="submit" value="KAYDET" name="calisanEklemeOnay" class="button">

            </div>
        </form>
    </div>

</div>