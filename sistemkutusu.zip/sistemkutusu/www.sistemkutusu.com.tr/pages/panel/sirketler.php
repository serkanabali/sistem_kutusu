<?php

function CalisanGetir($db, $AktifKullaniciSirket)
{
    $calisanlar = $db->prepare("SELECT c.id as calisan_id, d.adi AS departman_adi, c.adi AS calisan_adi, c.soyadi AS calisan_soyadi, c.email as calisan_email, s.adi AS sirket_adi FROM departmanlar d JOIN calisanlar c ON d.id = c.departmanID JOIN sirketler s ON d.sirketID = s.id where s.adi=?");
    $calisanlar->execute([$AktifKullaniciSirket]);

    return $calisanlar;
}

function DepartmanGetir($db, $AktifKullaniciSirket)
{

    $departmanlar = $db->prepare("Select * from departmanlar where sirketID=(Select id from sirketler where adi=?)");

    $departmanlar->execute([$AktifKullaniciSirket]);

    return $departmanlar;
}

function SirketGetir($db, $AktifKullaniciSirket)
{

    $sirket = $db->prepare("Select * from sirketler where sirketID=(Select id from sirketler where adi=?)");

    $sirket->execute([$AktifKullaniciSirket]);

    return $sirket;
}

?>

<?php
if (isset($_POST['calisanEklemeOnay'])) {
    $eklemeIsim = $_POST['CalEkleIsim'];
    $eklemeSoyisim = $_POST['CalEkleSoyisim'];
    $eklemeEmail = $_POST['CalEkleEmail'];
    $eklemeDepartman = $_POST['CalEklemeDepartman'];
    $eklemeParola = $_POST['CalEkleParola'];
    $eklemeParolaTekrar = $_POST['CalEkleParolaTekrar'];

    if (empty($eklemeIsim) || empty($eklemeSoyisim) || empty($eklemeEmail) || empty($eklemeDepartman) || empty($eklemeParola) || empty($eklemeParolaTekrar)) {
        // Gerekli alanlardan biri veya daha fazlası boş
        echo "Lütfen tüm alanları doldurun.";
    } else {

        if ($eklemeParola === $eklemeParolaTekrar) {
            $departmanlar = $db->prepare("INSERT INTO calisanlar (adi, soyadi, email, parola, departmanID) 
            VALUES (?, ?, ?, ?, (SELECT id FROM departmanlar WHERE adi = ? AND sirketID = (Select id from sirketler where adi=?)))");

            $departmanlar->execute([$eklemeIsim, $eklemeSoyisim, $eklemeEmail, $eklemeParola, $eklemeDepartman, $AktifKullaniciSirket]);
            if ($departmanlar) {
                //başarı Mesajı

            }
        } else {
            // Parolalar eşleşmiyor, hata mesajı gösterilebilir veya işlem durdurulabilir
            echo $eklemeDepartman;
        }
    }
}
?>

<?php
if (isset($_POST['calisanSil'])) {
    if (isset($_POST['checkboxkontrol'])) {
        $SeciliElemanlarSilme = $_POST['checkboxkontrol'];

        foreach ($SeciliElemanlarSilme as $eleman) {
            $SilmeIslemi = $db->query("DELETE FROM calisanlar WHERE ID=$eleman", PDO::FETCH_ASSOC);
        }
    } else {
    }
}
?>

<div class="calisan-ekle">

    <h1>Şirket Bilgileri</h1>

    <div class="ekleme-duzen">
        <div class="aciklama">
            <h4>Şirket Adi:</h4>
            
        </div>
        <div class="aciklama-giris">
            <input type="text" required name="CalEkleIsim" value="<?=$AktifKullaniciSirket?>" disabled  class="panel-veri-giris">
        </div>
    </div>
  

</div>