<?php
@session_start();
define("DATA", "include/");
define("SAYFA", "sayfalar/");
include_once(DATA . "db.php");
define("SITE",$url);
@ob_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/girisstyle.css">
    <title>Panel Giriş</title>
</head>

<body>
    <?php
    if ($_GET && !empty($_GET["sayfa"])) {
        $sayfa = $_GET["sayfa"] . ".php";
        if (file_exists(SAYFA . $sayfa)) {
            include_once(SAYFA . $sayfa);
        } else {
            include_once(SAYFA . "giris.php");
        }
    } else {
        include_once(SAYFA . "giris.php");
    }
    ?>
</body>

</html>