<?php
if (isset($_POST["kayitol"])) {


    $kisletmeAdi = $_POST["isletmeAdi"];
    $kKisiAdi = $_POST["kisiAdi"];
    $kKisiSoyadi = $_POST["KisiSoyadi"];
    $kKisiMail = $_POST["KisiMail"];
    $kKisiSifre = $_POST["KisiSifre"];
    $kKisiKontrol = $_POST["KisiSifreKontrol"];


    if (isset($kisletmeAdi) && isset($kKisiAdi) && isset($kKisiSoyadi) && isset($kKisiMail) && isset($kKisiSifre)) {

        $stmt = $db->prepare("SELECT ID FROM calisanlar WHERE email=?");
        $stmt->execute([$kKisiMail]);
        $kullanici = $stmt->fetch();

        if($kullanici) {
            //Bu e-posta adresi zaten kayıtlı!
            
        }else{
            if ($kKisiSifre == $kKisiKontrol) {
                $SifrelenmisSifre = password_hash($kKisiSifre, PASSWORD_DEFAULT);
                $eklesirket = $db->exec("INSERT INTO sirketler(adi) VALUES ('$kisletmeAdi')");
                $ekledepartman = $db->exec("INSERT INTO departmanlar(adi,sirketID) values ('Yönetici' , (SELECT ID FROM sirketler WHERE adi = '$kisletmeAdi'))");
                $eklekisi = $db->exec("INSERT INTO calisanlar(adi,soyadi,email,parola,departmanID) VALUES ('$kKisiAdi','$kKisiSoyadi','$kKisiMail', '$SifrelenmisSifre',(Select ID from departmanlar where sirketID=(Select ID from Sirketler where adi='$kisletmeAdi')))");

                if ($eklesirket && $ekledepartman && $eklekisi) {
                    ob_clean(); // Sadece tamponu temizle, çıktıyı gönderme
                    echo"Kayıt Başarılı";

                    ?>

                    <meta http-equiv="refresh" content="1;url=panel.php" />
                    <?php
                    
                    exit;
                } else {
                    // Beklenmeyen bir hata oluştu lütfen tekrar deneyiniz
                }
            }else{
                //Şifreler uyuşmamaktadır

            }
        }




    } else {
        //hata mesajı uygun alanlarla doldurun
    }
}
?>