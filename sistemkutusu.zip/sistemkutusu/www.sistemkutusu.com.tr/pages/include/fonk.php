<?php

require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

function MailGonder($gonderilecekmail, $icerik, $isimsoyisim)
{
    //Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);

    try {

        //Server settings
        $mail->SMTPDebug = 0;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.office365.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'yapimepwebsitesi@hotmail.com';          //SMTP username
        $mail->Password   = 'T2zpG@_Xh=,!uJ2';                        //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;            //Enable implicit TLS encryption
        $mail->Port       = 587;
        $mail->CharSet = "UTF-8";
        //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        //Recipients
        $mail->setFrom('yapimepwebsitesi@hotmail.com', 'Sistem Kutusu');
        $mail->addAddress($gonderilecekmail, $isimsoyisim);     //Add a recipient

        //Optional name

        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Mailiniz Var';
        $mail->Body    = $icerik;

        if ($mail->send()) {
            return true;
        } else {
            return false;
        }
    } catch (Exception $e) {
        // Hata oluştuğunda yapılacak işlemler
    }
}
function KodOlustur($length) {
    $chars = '0123456789';
    $code = '';
    
    // Belirtilen uzunluktaki kodu oluştur
    for ($i = 0; $i < $length; $i++) {
        $code .= $chars[rand(0, strlen($chars) - 1)];
    }
    
    return $code;
}
