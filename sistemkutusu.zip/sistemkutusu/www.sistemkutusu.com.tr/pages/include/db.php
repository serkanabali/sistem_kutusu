<?php
$db = new PDO("mysql:host=localhost; dbname=sistemkutusu; charset=utf8", "root", "");  
$url = "http://localhost/www.sistemkutusu.com.tr";
?>

